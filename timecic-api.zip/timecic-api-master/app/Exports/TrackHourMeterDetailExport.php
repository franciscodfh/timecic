<?php

namespace App\Exports;

use App\Models\Track;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithCustomCsvSettings;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Excel;

class TrackHourMeterDetailExport implements
    FromCollection,
    ShouldAutoSize,
    WithColumnFormatting,
    WithHeadings,
    WithMapping,
    WithCustomCsvSettings
{
    use Exportable;

    public $writerType = Excel::CSV;

    /** @var User */
    private $authUser;

    /** @var array */
    private array $filters = [];

    public function __construct($filters, ?User $authUser = null)
    {
        $this->authUser = $authUser ?? Auth::user();
        $this->filters = $filters;
    }

    public function collection()
    {
        $tables = Track::getTables();
        $queryUnion = null;
        foreach ($tables as $key => $table) {
            $alias = 't_' . $table->TABLE_NAME;
            $query = DB::query()->fromRaw($table->TABLE_NAME . ' AS ' . $alias . ' USE INDEX(`index_columns_filter_track`)')
                ->join('devices', $alias . ".device_id", '=', 'devices.id')
                ->join('machines', "devices.machine_id", '=', 'machines.id')
                ->selectRaw("devices.id, machines.plate, $alias.created_at, $alias.hour_meter_active as hour_meter_active_start")
                ->selectSub("SELECT hour_meter_active
                                        FROM " . $table->TABLE_NAME . "
                                        WHERE DAY(" . $table->TABLE_NAME . ".created_at) = DAY(" . $alias . ".created_at)
                                        ORDER BY created_at DESC
                                        LIMIT 1", 'hour_meter_active_end')
                ->selectSub("SELECT hour_meter_active
                                        FROM " . $table->TABLE_NAME . "
                                        ORDER BY created_at DESC
                                        LIMIT 1", 'active_current')
                ->whereBetween(
                    "$alias.created_at",
                    [
                        $this->filters['beginDate'] . ' 00:00:00',
                        $this->filters['finalDate'] . ' 23:59:59'
                    ])
                ->groupByRaw("DAY($alias.created_at)")
                ->orderBy("$alias.created_at");

            if ($key === 0) $queryUnion = $query;
            else $queryUnion->union($query);
        }

        return $queryUnion->get();
    }

    public function columnFormats(): array
    {
        return [
            'D' => '#',
        ];
    }

    public function headings(): array
    {
        return [
            'fecha_reporte',
            'id_dispostivo',
            'id_maquinaria',
            'horometro_inicial',
            'horometro_final',
            'horometro_actual',
            'horas_uso'
        ];
    }

    public function map($row): array
    {
        return [
            (new Carbon($row->created_at))->timezone('America/Santiago')->format('Y-m-d H:i:s'),
            $row->id,
            $row->plate ?? '-',
            $row->hour_meter_active_start ?? '0',
            $row->hour_meter_active_end ?? '0',
            $row->active_current ?? '0',
            intval($row->hour_meter_active_end) - intval($row->hour_meter_active_start) ?? '0'
        ];
    }


    public function getCsvSettings(): array
    {
        return [
            'delimiter' => ';',
            'use_bom' => false,
            'output_encoding' => 'ISO-8859-1',
        ];
    }
}
