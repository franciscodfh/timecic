<?php

namespace App\Exports;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Excel;

class TrackExport implements
    FromCollection,
    ShouldAutoSize,
    WithColumnFormatting,
    WithHeadings,
    WithMapping
{
    use Exportable;

    public $writerType = Excel::CSV;

    /** @var User */
    private $authUser;

    /** @var array */
    private array $filters = [];

    public function __construct($filters, ?User $authUser = null)
    {
        $this->authUser = $authUser ?? Auth::user();
        $this->filters = $filters;
    }

    public function collection()
    {
        $id = $this->filters['id'];

        $query = DB::table("{$id}_tracks")
            ->select([
                'id',
                'device_id',
                'latitude',
                'longitude',
                'status',
                'status_text',
                'battery',
                'stack',
                'humidity',
                'temperature',
                'created_at'
            ]);

        if (isset($this->filters['beginDate']) and isset($this->filters['finalDate']))
            $query->whereBetween('created_at', [$this->filters['beginDate'] . ' 00:00:00', $this->filters['finalDate'] . ' 23:59:59']);

        $query->orderBy($this->filters['sortField'], $this->filters['sort'])
            ->limit($this->filters['limit']);

        return $query->get();
    }

    public function columnFormats(): array
    {
        return [
            'D' => '#',
        ];
    }

    public function headings(): array
    {
        return [
            'ID',
            'DEVICE',
            'LATITUD',
            'LONGITUDE',
            'ESTATUS',
            'ESTATUS TEXTO',
            'BATERIA',
            'STACK',
            'HUMEDAD',
            'TEMPERATURA',
            'FECHA CREACION'
        ];
    }

    public function map($row): array
    {
        return [
            $row->id,
            $row->device_id,
            $row->latitude ?? '-',
            $row->longitude ?? '-',
            $row->status ?? '-',
            $row->status_text ?? '-',
            $row->battery ?? '-',
            $row->stack ?? '-',
            $row->humidity ?? '-',
            $row->temperature ?? '-',
            (new Carbon($row->created_at))->timezone('America/Santiago')->format('Y-m-d H:i:s')
        ];
    }
}
