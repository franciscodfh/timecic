<?php

namespace App\Exports;

use App\Models\Machine;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Excel;

class MachineExport implements
    FromCollection,
    ShouldAutoSize,
    WithColumnFormatting,
    WithHeadings,
    WithMapping
{
    use Exportable;

    public $writerType = Excel::CSV;

    /** @var User */
    private $authUser;

    /** @var array */
    private array $filters = [];

    public function __construct($filters, ?User $authUser = null)
    {
        $this->authUser = $authUser ?? Auth::user();
        $this->filters = $filters;
    }

    public function collection()
    {
        $filters = $this->filters;

        $query = Machine::query()
            ->whereHas('device', function ($q) use ($filters) {
                $q->search($filters['prefix']);
            })->with(['device']);

        if (isset($filters['beginDate']) and isset($filters['finalDate']))
            $query->whereBetween('created_at', [$filters['beginDate'] . ' 00:00:00', $filters['finalDate'] . ' 23:59:59']);

        $query->orderBy($filters['sortField'], $filters['sort'])
            ->limit($filters['limit']);

        return $query->get();
    }

    public function columnFormats(): array
    {
        return [
            'D' => '#',
        ];
    }

    public function headings(): array
    {
        return [
            'PLACA',
            'NOMBRE',
            'ESTATUS',
            'DISPOSITIVO',
            'FECHA CREACION'
        ];
    }

    public function map($row): array
    {
        return [
            $row->plate,
            $row->name ?? '-',
            $row->status ?? '-',
            $row->device->prefix.'-'.$row->device->id ?? '-',
            (new Carbon($row->created_at))->timezone('America/Santiago')->format('Y-m-d H:i:s')
        ];
    }
}
