<?php

namespace App\Http\Controllers;

use App\Exports\TrackExport;
use App\Exports\TrackHourMeterDetailExport;
use App\Exports\TrackHourMeterExport;
use App\Http\Requests\GraphStatusMachinesRequest;
use App\Http\Requests\GraphStatusMonthRequest;
use App\Http\Requests\TrackHourMeterRequest;
use App\Http\Requests\TrackIndex;
use App\Http\Requests\TrackStore;
use App\Models\Device;
use App\Models\Track;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\TrackExport as TrackExportRequest;
use Maatwebsite\Excel\Facades\Excel;

class TrackController extends Controller
{

    /**
     * @OA\Get(
     *     path="/api/tracks",
     *     summary="get records track",
     *     description="index tracks",
     *     operationId="trackIndex",
     *     tags={"track"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="beginDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-07",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="finalDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-30",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="sort",
     *          in="query",
     *          required=false,
     *          example="asc",
     *          schema={
     *              "type"="string",
     *              "default"="desc"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="sortField",
     *          in="query",
     *          required=false,
     *          example="latitude",
     *          schema={
     *              "type"="string",
     *              "default"="id"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="limit",
     *          in="query",
     *          required=false,
     *          example="10",
     *          schema={
     *              "type"="numeric",
     *              "default"="100"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="prefix",
     *          in="query",
     *          required=true,
     *          example="TEST",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="id",
     *          in="query",
     *          required=true,
     *          example="123",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. tracks records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data":{"records":{{"id":1,"latitude":"23123.232222","longitude":"31000000","device_id":"123","status":null,"status_text":null,"battery":null,"stack":null,"timestamps":null,"sd_status":null,"humidity":null,"atmospheric_pressure":null,"regulator01":null,"regulator02":null,"regulator03":null,"regulator04":null,"created_at":"2022-06-23T03:41:48.000000Z","updated_at":"2022-06-23T03:42:20.000000Z"}}},"extra":{}}, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. tracks not get records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al consultar registros", "extra": {} }, summary="An result error exception.")
     *         )
     *     )
     * )
     */
    public function index(TrackIndex $request)
    {
        try {
            $device = Device::where('prefix', $request->get('prefix'))->where('id', $request->id)->first();
            if (!$device) throw new \Exception('Device not found');

            $query = DB::table("{$request->id}_tracks");

            if (isset($this->filters['beginDate']) and isset($this->filters['finalDate']))
                $query->whereBetween('created_at', [$this->filters['beginDate'] . ' 00:00:00', $this->filters['finalDate'] . ' 23:59:59']);

            $query->orderBy($request->sortField, $request->sort);

            return $query->paginate($request->get('per_page') ?? 10);

        } catch (\Exception $exception) {
            return api()->error('Error al consultar track', [], 500, $exception);
        }
    }

    /**
     * @OA\Post(
     *     path="/oauth2/tracks",
     *     summary="store new track by device",
     *     description="store record",
     *     operationId="trackStore",
     *     tags={"track"},
     *     @OA\RequestBody(
     *     required=true,
     *     description="track data",
     *     @OA\JsonContent(
     *          required={"grant_type","client_id","scope","client_secret"},
     *          @OA\Property(
     *              property="grant_type",
     *              type="string",
     *              example="client_credentials"
     *          ),
     *          @OA\Property(
     *               property="client_id",
     *               type="integer",
     *               example="3"
     *          ),
     *          @OA\Property(
     *               property="scope",
     *               type="string",
     *               example="*"
     *          ),
     *          @OA\Property(
     *               property="client_secret",
     *               type="string",
     *               example="iAj9NKD4RwEI6vfpl6gcmkH1GRuEYpZqXofLMLAC"
     *          ),
     *          @OA\Property(
     *               property="latitude",
     *               type="string",
     *               example="123213123.123"
     *          ),
     *          @OA\Property(
     *               property="longitude",
     *               type="string",
     *               example="-123213123.123"
     *          ),
     *          @OA\Property(
     *               property="device_id",
     *               type="string",
     *               example="TEST"
     *          ),
     *          @OA\Property(
     *               property="status",
     *               type="decimal",
     *               example="1"
     *          ),
     *          @OA\Property(
     *               property="status_text",
     *               type="string",
     *               example="movimiento"
     *          ),
     *          @OA\Property(
     *               property="battery",
     *               type="decimal",
     *               example="15.5"
     *          ),
     *          @OA\Property(
     *               property="stack",
     *               type="decimal",
     *               example="15.5"
     *          ),
     *          @OA\Property(
     *               property="timestamps",
     *               type="datetime",
     *               example="123123123231"
     *          ),
     *          @OA\Property(
     *               property="sd_status",
     *               type="string",
     *               example="ok"
     *          ),
     *          @OA\Property(
     *               property="humidity",
     *               type="decimal",
     *               example="50.5"
     *          ),
     *          @OA\Property(
     *               property="atmospheric_presure",
     *               type="decimal",
     *               example="15.5"
     *          ),
     *          @OA\Property(
     *               property="regulator01",
     *               type="decimal",
     *               example="15.5"
     *          ),
     *          @OA\Property(
     *               property="regulator02",
     *               type="decimal",
     *               example="15.5"
     *          ),
     *          @OA\Property(
     *               property="regulator03",
     *               type="decimal",
     *               example="15.5"
     *          ),
     *          @OA\Property(
     *               property="regulator04",
     *               type="decimal",
     *               example="15.5"
     *          ),
     *      )
     *  ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. track stored",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data":{"record":{"id":1,"latitude":"23123.232222","longitude":"31000000","device_id":"123","status":null,"status_text":null,"battery":null,"stack":null,"timestamps":null,"sd_status":null,"humidity":null,"atmospheric_pressure":null,"regulator01":null,"regulator02":null,"regulator03":null,"regulator04":null,"created_at":"2022-06-23T03:41:48.000000Z","updated_at":"2022-06-23T03:42:20.000000Z"}},"extra":{}}, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. store",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al guardar track", "extra": {} }, summary="An result error exception.")
     *         )
     *     )
     * )
     */
    public function store(TrackStore $request)
    {
        try {
            DB::beginTransaction();
            $device = Device::where('prefix', $request->get('device_prefix'))
                ->where('id', $request->get('device_id'))
                ->first();

            if (!$device) throw new \Exception('Device not found');
            $oldTrack = $device->latestTrack()->first();
            if ($oldTrack) {
                $oldTrack->update($request->except(['grant_type', 'client_id', 'client_secret', 'scope', 'device_prefix']));
            } else {
                $track = new Track();
                $track->store($request->all());
            }

            DB::commit();
            return api()->ok([
                'record' => $oldTrack ?? $track
            ]);
        } catch (\Exception $exception) {
            DB::rollBack();
            return api()->error('Error al guardar track', [], 500, $exception);
        }
    }

    public function export(TrackExportRequest $request)
    {
        try {
            $export = new TrackExport($request->all());
            $response = array(
                'name' => 'device_' . $request->id . '_' . now()->format('YmdHis') . '.csv',
                'file' => "data:application/vnd.ms-csv;base64," . base64_encode(Excel::raw($export, $export->writerType))
            );
            return api()->ok($response);
        } catch (\Exception $exception) {
            return api()->error('Error al exportar', [], 500, $exception);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/graph/tracks",
     *     summary="data to graph for tracks",
     *     description="graph tracks",
     *     operationId="graphTracks",
     *     tags={"track"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="beginDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-07",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="finalDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-30",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="device_id",
     *          in="query",
     *          required=false,
     *          example="123",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. track stored",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={{{"plate":"AAA111","total":15795,"movement":"7836","ralenti":"7959"}}}, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error al exportar",
     *     )
     * )
     */
    public function graph(GraphStatusMonthRequest $request)
    {
        try {
            $tables = Track::getTables($request->get('device_id'));
            $queryUnion = null;
            foreach ($tables as $key => $table) {
                $query = DB::query()->fromRaw($table->TABLE_NAME . ' USE INDEX(`index_columns_filter_track`)')
                    ->join('devices', "$table->TABLE_NAME.device_id", '=', 'devices.id')
                    ->join('machines', "devices.machine_id", '=', 'machines.id')
                    ->selectRaw("machines.plate,
                            COUNT($table->TABLE_NAME.id) AS total,
                            SUM(IF($table->TABLE_NAME.status = 2, 1, 0)) AS active,
                            SUM(IF($table->TABLE_NAME.status = 0, 1, 0)) AS inactive,
                            SUM(IF($table->TABLE_NAME.status = 1, 1, 0)) AS ralenti")
                    ->groupBy('machines.plate')
                    ->whereMonth("$table->TABLE_NAME.created_at", $request->current_month)
                    ->whereYear("$table->TABLE_NAME.created_at", $request->year);

                if ($key === 0) $queryUnion = $query;
                else $queryUnion->union($query);
            }
            return $queryUnion->get();
        } catch (\Exception $exception) {
            return api()->error('Error al consultar', [], 500, $exception);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/graph/tracks/monthly-comparison",
     *     summary="data to graph for tracks",
     *     description="graph tracks",
     *     operationId="graphTracksMonthly",
     *     tags={"track"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="month",
     *          in="query",
     *          required=false,
     *          example="07",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="device_id",
     *          in="query",
     *          required=false,
     *          example="123",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. track stored",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={ "last_month": { "total": 125, "active": 43, "inactive": 42, "ralenti": 40 }, "month": { "2022-09-11": { { "created_at": "2022-09-11", "total": 25, "active": "8", "inactive": "10", "ralenti": "7" }, { "created_at": "2022-09-11", "total": 25, "active": "1", "inactive": "14", "ralenti": "10" }, { "created_at": "2022-09-11", "total": 25, "active": "9", "inactive": "6", "ralenti": "10" }, { "created_at": "2022-09-11", "total": 25, "active": "7", "inactive": "10", "ralenti": "8" }, { "created_at": "2022-09-11", "total": 24, "active": "10", "inactive": "6", "ralenti": "8" } }, "2022-09-12": { { "created_at": "2022-09-12", "total": 1, "active": "1", "inactive": "0", "ralenti": "0" } } } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error al consultar",
     *     )
     * )
     */
    public function graphLines(GraphStatusMonthRequest $request)
    {
        try {
            $tables = Track::getTables($request->get('device_id'));
            $queryUnionMonth = null;
            $queryUnionLastMonth = null;
            foreach ($tables as $key => $table) {
                // last month
                $queryI = DB::query()->fromRaw($table->TABLE_NAME . ' USE INDEX(`index_columns_filter_track`)')
                    ->selectRaw("
                            COUNT($table->TABLE_NAME.id) AS total,
                            SUM(IF($table->TABLE_NAME.status = 2, 1, 0)) AS active,
                            SUM(IF($table->TABLE_NAME.status = 0, 1, 0)) AS inactive,
                            SUM(IF($table->TABLE_NAME.status = 1, 1, 0)) AS ralenti")
                    ->whereMonth("$table->TABLE_NAME.created_at", $request->last_month)
                    ->whereYear("$table->TABLE_NAME.created_at", $request->year);

                if ($key === 0) $queryUnionLastMonth = $queryI;
                else $queryUnionLastMonth->union($queryI);
                // current month
                $queryII = DB::query()->fromRaw($table->TABLE_NAME . ' USE INDEX(`index_columns_filter_track`)')
                    ->selectRaw("$table->TABLE_NAME.created_at,
                            COUNT($table->TABLE_NAME.id) AS total,
                            SUM(IF($table->TABLE_NAME.status = 2, 1, 0)) AS active,
                            SUM(IF($table->TABLE_NAME.status = 0, 1, 0)) AS inactive,
                            SUM(IF($table->TABLE_NAME.status = 1, 1, 0)) AS ralenti")
                    ->groupBy("$table->TABLE_NAME.created_at")
                    ->whereMonth("$table->TABLE_NAME.created_at", $request->current_month)
                    ->whereYear("$table->TABLE_NAME.created_at", $request->year);

                if ($key === 0) $queryUnionMonth = $queryII;
                else $queryUnionMonth->union($queryII);
            }

            return [
                'last_month' => $queryUnionLastMonth->get()->reduce(function ($carry, $value) {
                    $carry['total'] += $value->total;
                    $carry['active'] += intval($value->active);
                    $carry['inactive'] += intval($value->inactive);
                    $carry['ralenti'] += intval($value->ralenti);
                    return $carry;
                }, [
                    'total' => 0,
                    'active' => 0,
                    'inactive' => 0,
                    'ralenti' => 0
                ]),
                'month' => $queryUnionMonth->orderBy('created_at')->get()->groupBy(function ($item) {
                    $item->created_at = (new Carbon($item->created_at))->format('Y-m-d');
                    return $item->created_at;
                }),
            ];
        } catch (\Exception $exception) {
            return api()->error('Error al consultar', [], 500, $exception);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/reports/tracks/detail",
     *     summary="data report tracks for day detail",
     *     description="report tracks",
     *     operationId="reportTracksDetail",
     *     tags={"track"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="beginDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-07",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="finalDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-30",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="device_id",
     *          in="query",
     *          required=false,
     *          example="123",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. track stored",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={ { { "id": "252", "plate": "93830-0796", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "32.00", "active_current": "35.00" }, { "id": "435", "plate": "64869", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "35.00", "active_current": "35.00" }, { "id": "348", "plate": "57447-7007", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "34.00", "active_current": "34.00" }, { "id": "292", "plate": "05669-9280", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "37.00", "active_current": "37.00" }, { "id": "472", "plate": "61553-4748", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "35.00", "active_current": "35.00" } } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error al consultar",
     *     )
     * )
     */
    public function tracksHourMeterDetail(GraphStatusMachinesRequest $request)
    {
        try {
            $tables = Track::getTables();
            $queryUnion = null;
            foreach ($tables as $key => $table) {
                $alias = 't_' . $table->TABLE_NAME;
                $query = DB::query()->fromRaw($table->TABLE_NAME . ' AS ' . $alias . ' USE INDEX(`index_columns_filter_track`)')
                    ->join('devices', $alias . ".device_id", '=', 'devices.id')
                    ->join('machines', "devices.machine_id", '=', 'machines.id')
                    ->selectRaw("devices.id, machines.plate, $alias.created_at, $alias.hour_meter_active as hour_meter_active_start")
                    ->selectSub("SELECT hour_meter_active
                                        FROM " . $table->TABLE_NAME . "
                                        WHERE DAY(" . $table->TABLE_NAME . ".created_at) = DAY(" . $alias . ".created_at)
                                        ORDER BY created_at DESC
                                        LIMIT 1", 'hour_meter_active_end')
                    ->selectSub("SELECT hour_meter_active
                                        FROM " . $table->TABLE_NAME . "
                                        ORDER BY created_at DESC
                                        LIMIT 1", 'active_current')
                    ->whereBetween(
                        "$alias.created_at",
                        [
                            $request->beginDate . ' 00:00:00',
                            $request->finalDate . ' 23:59:59'
                        ])
                    ->groupByRaw("DAY($alias.created_at)")
                    ->orderBy("$alias.created_at");

                if ($key === 0) $queryUnion = $query;
                else $queryUnion->union($query);
            }

            return $queryUnion->paginate($request->get('per_page') ?? 10);

        } catch (\Exception $exception) {
            return api()->error('Error al consultar', [], 500, $exception);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/reports/tracks",
     *     summary="data report tracks for day",
     *     description="report tracks",
     *     operationId="reportTracks",
     *     tags={"track"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="date",
     *          in="query",
     *          required=false,
     *          example="2022-07-07",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. track stored",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={ { { "id": "252", "plate": "93830-0796", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "32.00", "active_current": "35.00" }, { "id": "435", "plate": "64869", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "35.00", "active_current": "35.00" }, { "id": "348", "plate": "57447-7007", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "34.00", "active_current": "34.00" }, { "id": "292", "plate": "05669-9280", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "37.00", "active_current": "37.00" }, { "id": "472", "plate": "61553-4748", "created_at": "2022-09-12 02:27:56", "hour_meter_active_start": "0.00", "hour_meter_active_end": "35.00", "active_current": "35.00" } } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error al consultar",
     *     )
     * )
     */
    public function tracksHourMeter(TrackHourMeterRequest $request)
    {
        try {
            $tables = Track::getTables();
            $queryUnion = null;
            foreach ($tables as $key => $table) {
                $alias = 't_' . $table->TABLE_NAME;
                $query = DB::query()->fromRaw($table->TABLE_NAME . ' AS ' . $alias . ' USE INDEX(`index_columns_filter_track`)')
                    ->join('devices', $alias . ".device_id", '=', 'devices.id')
                    ->join('machines', "devices.machine_id", '=', 'machines.id')
                    ->selectRaw("devices.id, machines.plate, $alias.created_at, $alias.hour_meter_active as hour_meter_active_start")
                    ->selectSub("SELECT hour_meter_active
                                        FROM " . $table->TABLE_NAME . "
                                        WHERE DAY(" . $table->TABLE_NAME . ".created_at) = DAY(" . $alias . ".created_at)
                                        ORDER BY created_at DESC
                                        LIMIT 1", 'hour_meter_active_end')
                    ->selectSub("SELECT hour_meter_active
                                        FROM " . $table->TABLE_NAME . "
                                        ORDER BY created_at DESC
                                        LIMIT 1", 'active_current')
                    ->whereDate("$alias.created_at", $request->date)
                    ->groupBy("$alias.device_id")
                    ->orderBy("$alias.created_at", "desc");

                if ($key === 0) $queryUnion = $query;
                else $queryUnion->union($query);
            }

            return $queryUnion->paginate($request->get('per_page') ?? 10);

        } catch (\Exception $exception) {
            return api()->error('Error al consultar', [], 500, $exception);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/export/tracks",
     *     summary="export xls records track hour meter",
     *     description="export tracks hour meter",
     *     operationId="trackExportHourMeter",
     *     tags={"track"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="date",
     *          in="query",
     *          required=false,
     *          example="2022-07-07",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. download file xls",
     *          @OA\JsonContent(
     *             @OA\Examples(example="result", value={ { "data": { "name": "tracks_hour_meter_general_20220918034321.csv", "file": "data:application\/vnd.ms-csv;base64,ImZlY2hhX3JlcG9ydGUi" }, "extra": {} } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error al exportar",
     *     )
     * )
     */
    public function exportTracksHourMeter(TrackHourMeterRequest $request)
    {
        try {
            $export = new TrackHourMeterExport($request->all());
            $response = array(
                'name' => 'tracks_hour_meter_general_' . now()->format('YmdHis') . '.csv',
                'file' => "data:application/vnd.ms-csv;base64," . base64_encode(Excel::raw($export, $export->writerType))
            );
            return api()->ok($response);
        } catch (\Exception $exception) {
            return api()->error('Error al exportar', [], 500, $exception);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/export/tracks/detail",
     *     summary="export xls records track detail hour meter",
     *     description="export tracks detail hour meter",
     *     operationId="trackExportHourMeterDetail",
     *     tags={"track"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="beginDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-07",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="finalDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-30",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. download file xls",
     *          @OA\JsonContent(
     *             @OA\Examples(example="result", value={ { "data": { "name": "tracks_hour_meter_detail_20220918034321.csv", "file": "data:application\/vnd.ms-csv;base64,ImZlY2hhX3JlcG9ydGUi" }, "extra": {} } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error al exportar",
     *     )
     * )
     */
    public function exportTracksHourMeterDetail(GraphStatusMachinesRequest $request)
    {
        try {
            $export = new TrackHourMeterDetailExport($request->all());
            $response = array(
                'name' => 'tracks_hour_meter_detail_' . now()->format('YmdHis') . '.csv',
                'file' => "data:application/vnd.ms-csv;base64," . base64_encode(Excel::raw($export, $export->writerType))
            );
            return api()->ok($response);
        } catch (\Exception $exception) {
            return api()->error('Error al exportar', [], 500, $exception);
        }
    }
}
