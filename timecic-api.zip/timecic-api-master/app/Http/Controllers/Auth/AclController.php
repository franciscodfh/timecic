<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;

class AclController extends Controller
{
    public function assignedRole(Request $request)
    {
        try {
            $role = Role::findOrFail($request->get('role_id'));
            $user = User::findOrFail($request->get('user_id'));

            $user->syncRoles($role);

            return api()->ok();
        } catch (\Exception $exception) {
            return api()->error('Ocurrio un error al intentar asignar un rol a un usuario', [], 500, $exception);
        }
    }

    public function removeRole(Request $request)
    {
        try {
            $role = Role::findOrFail($request->get('role_id'));
            $user = User::findOrFail($request->get('user_id'));
            $user->removeRole($role);

            return api()->ok();
        } catch (\Exception $exception) {
            return api()->error('Ocurrio un error al intentar remover un rol a un usuario', [], 500, $exception);
        }
    }
}
