<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use OpenApi\Annotations as OA;

class AuthController extends Controller
{

    /**
     * @OA\Post(
     *     path="/api/auth/register",
     *     summary="register new user",
     *     description="Adds a new user",
     *     operationId="addUser",
     *     tags={"auth"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                     property="name",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="email",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="password",
     *                     type="string"
     *                 ),
     *                 example={"name": "Leonel Messi", "email": "lapulga10@gmail.com", "password": "123456"}
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="object user and token authorization",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"user": { "id": 1, "name": "Leonel Messi", "email": "lapulga10@gmail.com"}, "token": ""}, summary="An result object."),
     *         )
     *     )
     * )
     */
    public function register(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required'
        ]);

        $data['password'] = bcrypt($request->password);

        $user = User::create($data);

        $token = $user->createToken('apiToken')->accessToken;

        return response([ 'user' => $user, 'token' => $token]);
    }

    /**
     * @OA\Post(
     *     path="/api/auth/login",
     *     summary="login to user",
     *     description="init session for user",
     *     operationId="login",
     *     tags={"auth"},
     *     @OA\RequestBody(
     *          required=true,
     *          description="Pass user credentials",
     *         @OA\JsonContent(
     *                  required={"email","password"},
     *                 @OA\Property(
     *                     property="email",
     *                     type="string",
     *                     example="lapulga10@gmail.com"
     *                 ),
     *                 @OA\Property(
     *                     property="password",
     *                     type="string",
     *                     example="123456"
     *                 ),
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="object user and token authorization",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"user": { "id": 1, "name": "Leonel Messi", "email": "lapulga10@gmail.com"}, "token": ""}, summary="An result object."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Error. login",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Incorrect Details. Please try again" }, summary="error credentials.")
     *         )
     *     )
     * )
     */
    public function login(Request $request)
    {
        $data = $request->validate([
            'email' => 'email|required',
            'password' => 'required'
        ]);

        if (!auth()->attempt($data)) {
            return response()->json(['error' => 'Datos incorrectos. Por favor intente de nuevo'], 422);
        }
        $userId = Auth::id();
        $user = User::find($userId);
        $token = $user->createToken('apiToken')->accessToken;
        $user->roles;

        return response()->json([
            'user' => $user,
            'token' => $token,
        ]);

    }

    /**
     * @OA\Post(
     *     path="/api/auth/logout",
     *     summary="logout to user",
     *     description="finish session for user",
     *     operationId="logout",
     *     tags={"auth"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="response ok",
     *     )
     * )
     */
    public function logout(Request $request)
    {
        $request->user()->token()->revoke();

        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }

    public function user(Request $request)
    {
        return response()->json($request->user());
    }
}
