<?php

namespace App\Http\Requests;

use Carbon\Carbon;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class TrackHourMeterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'device_id' => 'sometimes|string|regex:/^\S*$/u',
            'date' => 'sometimes|date_format:Y-m-d',
        ];
    }

    public function prepareForValidation()
    {
        $mergeData = [];

        if (!$this->has('date'))
            $mergeData['date'] = Carbon::now()->format('Y-m-d');

        return $this->merge($mergeData);
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(api()->validator($validator->errors()));
    }
}
