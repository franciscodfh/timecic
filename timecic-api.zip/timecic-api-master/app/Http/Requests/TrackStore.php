<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\Log;

class TrackStore extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        Log::info('Track::store => '.json_encode($this->all()));
        return [
            'latitude' => 'sometimes|string',
            'longitude' => 'sometimes|string',// la data se envia por partes, cuando el track de un dispositivo se envia en menos de un
            // intervalo de 15 minutos pertenecen al mismo lote
            'device_id' => 'required|string|regex:/^\S*$/u',
            'device_prefix' => 'required|string|regex:/^\S*$/u',
            'status' =>  'sometimes|numeric',
            'status_text' => 'sometimes|string',
            'battery' => 'sometimes|numeric', // bateria
            'stack' => 'sometimes|numeric', // pila
            'timestamps' => 'sometimes|date',
            'sd_status' => 'sometimes|string',
            'humidity' => 'sometimes|numeric', //humedad
            'temperature' => 'sometimes|numeric', //humedad
            'hour_meter_active' => 'sometimes|numeric', // hour meter active
            'hour_meter_ralenti' => 'sometimes|numeric', // hour meter ralenti
            'atmospheric_pressure' => 'sometimes|numeric', // presionatm
            'regulator01' => 'sometimes|numeric', // regulador
            'regulator02' => 'sometimes|numeric', // regulador
            'regulator03' => 'sometimes|numeric', //regulador
            'regulator04' => 'sometimes|numeric', // regulador
        ];
    }

    public function prepareForValidation()
    {
        $mergeData = [];

        $except = collect(['name', 'time', 'identifiers', 'correlation_ids', 'origin', 'context', 'visibility', 'unique_id']);
        $except->each(fn ($key) => $this->request->remove($key));

        if ($this->has('bateria'))
            $mergeData['battery'] = $this->get('bateria');

        if ($this->has('pila'))
            $mergeData['stack'] = $this->get('pila');

        if ($this->has('humedad'))
            $mergeData['humidity'] = $this->get('humedad');

        if ($this->has('atmospheric_pressure'))
            $mergeData['presionatm'] = $this->get('atmospheric_pressure');

        if ($this->has('regulador01'))
            $mergeData['regulator01'] = $this->get('regulador01');
        if ($this->has('regulador02'))
            $mergeData['regulator02'] = $this->get('regulador02');
        if ($this->has('regulador03'))
            $mergeData['regulator03'] = $this->get('regulador03');
        if ($this->has('regulador04'))
            $mergeData['regulator04'] = $this->get('regulador04');

        return $this->merge($mergeData);
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(api()->validator($validator->errors()));
    }
}
