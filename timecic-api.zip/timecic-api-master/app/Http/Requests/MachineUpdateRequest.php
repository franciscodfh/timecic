<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class MachineUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'device_id' => 'required|string|min:1|max:10|regex:/^\S*$/u|exists:devices,id',
            'device_prefix' => 'sometimes|string|max:10|regex:/^\S*$/u|min:1',
            'name' => 'sometimes|string|max:25',
            'plate' => 'sometimes|string|max:25|min:1'
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(api()->validator($validator->errors()));
    }
}
