<?php

namespace App\Models;

use App\Models\Relations\TrackRelations;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Track extends Model
{
    use HasFactory, TrackRelations;

    protected $fillable = [
        'latitude',
        'longitude',
        'device_id',
        'status',
        'status_text',
        'battery',
        'stack',
        'temperature',
        'timestamps',
        'sd_status',
        'humidity',
        'atmospheric_pressure',
        'hour_meter_ralenti',
        'hour_meter_active',
        'regulator01',
        'regulator02',
        'regulator03',
        'regulator04',
    ];

    /**
     * @param $data
     * @return $this
     */
    public function store($data): static
    {
        $this->setTable($data['device_id'] . '_tracks');
        $this->fill($data);
        $this->save();
        return $this;
    }

    public function scopeForDates($query, $beginDate, $finalDate)
    {
        if ($beginDate and $finalDate) {
            $query->whereBetween('created_at', [$beginDate . ' 00:00:00', $finalDate . ' 23:59:59']);
        }
    }

    public static function getTables($deviceId = null)
    {
        $query = DB::table('information_schema.TABLES')
            ->select('TABLE_NAME')
            ->where('TABLE_NAME', 'LIKE', '%_tracks');

        if ($deviceId)
            $query->where('TABLE_NAME', '=', "{$deviceId}_tracks");

        return $query->get();
    }
}
