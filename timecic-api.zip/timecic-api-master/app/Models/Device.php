<?php

namespace App\Models;

use App\Models\Relations\DeviceRelations;
use App\Observers\DeviceObserver;
use App\Traits\Trackable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

/**
 * @property string $id
 * @property string $prefix
 */
class Device extends Model
{
    use HasFactory, SoftDeletes, DeviceRelations, Trackable;

    protected $fillable = [
        'prefix',
        'id'
    ];

    protected $casts = [
        'id' => 'string'
    ];

    public $incrementing = false;

    public function scopeSearch(Builder $query, $value = null)
    {
        if (!$value) return;
        $search = "%{$value}%";
        $query->where(function ($sub) use ($search) {
           $sub->where(DB::raw("CONCAT(prefix, '-', id)"), 'LIKE', $search)
               ->orWhere(DB::raw("CONCAT(id, '-', prefix)"), 'LIKE', $search)
               ->orWhere('id', 'LIKE', $search)
               ->orWhere('prefix', 'LIKE', $search);
        });
    }
}
