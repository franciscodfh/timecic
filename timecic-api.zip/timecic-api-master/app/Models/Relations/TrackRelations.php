<?php

namespace App\Models\Relations;

trait TrackRelations {

}
