<?php

namespace App\Traits;

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

trait Trackable {

    public function migrateUp()
    {
        if (!Schema::hasTable($this->id . "_tracks")) {
            Schema::create($this->id.'_tracks', function (Blueprint $table) {
                $table->unsignedInteger('id', true);
                $table->string('latitude')->nullable();
                $table->string('longitude')->nullable();
                $table->string('device_id')->index();
                $table->integer('status')->nullable();
                $table->string('status_text')->nullable(); // relanti | movimiento
                $table->decimal('battery')->nullable(); // bateria
                $table->decimal('stack')->nullable(); // pila
                $table->dateTime('timestamps')->nullable();
                $table->string('sd_status')->nullable();
                $table->decimal('temperature')->nullable();
                $table->decimal('humidity')->nullable(); //humedad
                $table->decimal('atmospheric_pressure')->nullable(); // presionatm
                $table->decimal('hour_meter_active')->nullable(); // hour meter active
                $table->decimal('hour_meter_ralenti')->nullable(); // hour meter ralenti
                $table->decimal('regulator01')->nullable(); // regulador
                $table->decimal('regulator02')->nullable(); // regulador
                $table->decimal('regulator03')->nullable(); //regulador
                $table->decimal('regulator04')->nullable(); // regulador

                $table->index([
                    'created_at',
                    'device_id',
                    'id',
                    'status'
                ], 'index_columns_filter_track');
                $table->timestamps();
            });
        }
    }

    public function migrateDown()
    {
        Schema::dropIfExists($this->id.'_tracks');
    }
}
