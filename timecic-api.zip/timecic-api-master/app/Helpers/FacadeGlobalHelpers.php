<?php

use App\Facades\Api;

function api() {
    return Api::getFacadeRoot();
}
