<?php

namespace Database\Seeders;

use App\Models\Device;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TrackSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        try {
            Device::factory()
                ->count(5)
                ->create()
                ->each(function (Device $device) {
                    $options = ['inactive', 'ralenti', 'active'];
                    $subMonth = now()->subMonth();
                    $month = now();
                    $device->migrateUp();
                    DB::beginTransaction();
                    $hours_active = 0;
                    $hours_ralenti = 0;
                    for ($i = 1; $i <= 25; $i++) {
                        $option = array_rand($options, 1);
                        DB::insert("INSERT INTO db_dev.`" . $device->id . "_tracks` (latitude, longitude, device_id, status, status_text, battery, stack, timestamps, sd_status, temperature, humidity, atmospheric_pressure, regulator01, regulator02, regulator03, regulator04, created_at, updated_at, hour_meter_active, hour_meter_ralenti) VALUES (null, null, '" . $device->id . "', '" . $option . "', '" . $options[$option] . "', null, null, null, null, null, null, null, null, null, null, null, '" . $subMonth->addDays($i) . "', '" . $subMonth->addDays($i) . "', '".$hours_active."', '".$hours_ralenti."')");
                        $hours_active += rand(1, 2);
                        $hours_ralenti += rand(1, 2);
                    }
                    $hours_active = 0;
                    $hours_ralenti = 0;
                    for ($i = 1; $i <= 25; $i++) {
                        $option = array_rand($options, 1);
                        DB::insert("INSERT INTO db_dev.`" . $device->id . "_tracks` (latitude, longitude, device_id, status, status_text, battery, stack, timestamps, sd_status, temperature, humidity, atmospheric_pressure, regulator01, regulator02, regulator03, regulator04, created_at, updated_at, hour_meter_active, hour_meter_ralenti) VALUES (null, null, '" . $device->id . "', '" . $option . "', '" . $options[$option] . "', null, null, null, null, null, null, null, null, null, null, null, '" . $month->addDays($i) . "', '" . $month->addDays($i) . "', '".$hours_active."', '".$hours_ralenti."')");
                        $hours_active += rand(1, 2);
                        $hours_ralenti += rand(1, 2);
                    }
                    DB::commit();
                });

        } catch (\Exception $exception) {
            DB::rollBack();
            dd($exception->getMessage());
        }

    }
}
