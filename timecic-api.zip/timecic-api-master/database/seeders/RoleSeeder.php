<?php

namespace Database\Seeders;

use App\Models\User;
use DateTime;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $roles = collect(['superadmin', 'operario']);

        $roles->each(function ($r) {
            $role = Role::create([
                'name'=> $r,
                'guard_name'=> "api"
            ]);

            $user = User::where('email', "$r@timecic.cl")->first();
            $user->assignRole($role);
        });
    }
}
