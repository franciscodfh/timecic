<?php

namespace Database\Seeders;

use DateTime;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $actions = collect(['index', 'read', 'show', 'destroy', 'update']);
        $models = collect(['track', 'user', 'machinary', 'device']);
        $permissions = collect([]);

        $models->each(function ($model) use ($actions, $permissions) {
            $actions->each(function ($action) use ($model, $permissions) {
                $permission = Permission::create([
                    'name'=> "$model.$action",
                    'guard_name'=> "api",
                ]);
                $permissions->push($permission);
            });
        });

        $roles = Role::whereIn('name', ['sysadmin', 'superadmin'])->get();

        $roles->each(fn ($role) => $role->syncPermissions($permissions));
    }
}
