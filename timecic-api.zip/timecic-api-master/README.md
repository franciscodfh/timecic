## use

```shell
php artisan passport:install
php artisan passport:client --client
```
