<?php

use App\Http\Controllers\Auth\RoleController;
use App\Http\Controllers\Auth\PermissionController;
use App\Http\Controllers\DeviceController;
use App\Http\Controllers\MachineController;
use App\Http\Controllers\TrackController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\AclController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/', function (Request $request) {
    return response()->json([
        'server' => 'timecic'
    ], 200);
});

Route::group([
    'prefix' => 'auth'
], function () {
    Route::post('login', [AuthController::class, 'login']);
    Route::post('register', [AuthController::class, 'register']);

    Route::group([
        'middleware' => 'auth:api'
    ], function () {
        Route::get('logout', [AuthController::class, 'logout']);
        Route::get('user', [AuthController::class, 'user']);
    });
});

Route::group(['middleware' => ['auth:api', 'role:superadmin']], function () {
    Route::post('assigned-role', [AclController::class, 'assignedRole']);
    Route::post('remove-role', [AclController::class, 'removeRole']);
});

Route::group(['middleware' => ['auth:api', 'role:superadmin']], function () {
    Route::resource('users', UserController::class);
    Route::resource('roles', RoleController::class);
    Route::resource('permissions', PermissionController::class);
    Route::resource('devices', DeviceController::class);
    Route::resource('machines', MachineController::class);
    Route::get('tracks', [TrackController::class, 'index']);
});

Route::group(['middleware' => ['auth:api', 'role:superadmin|operario']], function () {
    Route::group([ 'prefix' => 'export' ], function () {
        Route::get('tracks', [TrackController::class, 'exportTracksHourMeter']);
        Route::get('tracks/detail', [TrackController::class, 'exportTracksHourMeterDetail']);
        Route::get('machines', [MachineController::class, 'export']);
    });
});

Route::group(['middleware' => ['auth:api', 'role:superadmin|operario']], function () {
    Route::group([ 'prefix' => 'graph' ], function () {
        Route::get('tracks', [TrackController::class, 'graph']);
        Route::get('tracks/monthly-comparison', [TrackController::class, 'graphLines']);
    });
});

Route::group(['middleware' => ['auth:api', 'role:superadmin']], function () {
    Route::group([ 'prefix' => 'restore' ], function () {
        Route::patch('machines/{id}', [MachineController::class, 'restore']);
        Route::patch('users/{id}', [UserController::class, 'restore']);
    });
});

Route::group(['middleware' => ['auth:api', 'role:superadmin|operario']], function () {
    Route::group([ 'prefix' => 'reports' ], function () {
        Route::get('tracks/detail', [TrackController::class, 'tracksHourMeterDetail']);
        Route::get('tracks', [TrackController::class, 'tracksHourMeter']);
    });
});