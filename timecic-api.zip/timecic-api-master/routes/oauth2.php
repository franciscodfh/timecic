<?php

use App\Http\Controllers\TrackController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('tracks', [ TrackController::class, 'store' ]);
Route::post('algo', fn (Request $request) => response()->json(['a'=>1, 'response' => $request->header()]));


