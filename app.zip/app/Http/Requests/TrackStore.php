<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Support\Facades\Log;

class TrackStore extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        Log::info('json completo => '.json_encode($this->all()));
        
        return [
            'latitude' => 'sometimes|string',
            'longitude' => 'sometimes|string',// la data se envia por partes, cuando el track de un dispositivo se envia en menos de un
            // intervalo de 15 minutos pertenecen al mismo lote
            'device_id' => 'required|string|regex:/^\S*$/u',
            'device_prefix' => 'required|string|regex:/^\S*$/u',
            'status' =>  'sometimes|numeric',
            'status_text' => 'sometimes|string',
            'battery' => 'sometimes|numeric', // bateria
            'stack' => 'sometimes|numeric', // pila
            'timestamps' => 'sometimes|date',
            'sd_status' => 'sometimes|string',
            'humidity' => 'sometimes|numeric', //humedad
            'temperature' => 'sometimes|numeric', //humedad
            'hour_meter_active' => 'sometimes|numeric', // hour meter active
            'hour_meter_ralenti' => 'sometimes|numeric', // hour meter ralenti
            'atmospheric_pressure' => 'sometimes|numeric', // presionatm
            'regulator01' => 'sometimes|numeric', // regulador
            'regulator02' => 'sometimes|numeric', // regulador
            'regulator03' => 'sometimes|numeric', //regulador
            'regulator04' => 'sometimes|numeric', // regulador
        ];
    }

    public function prepareForValidation()
    {
        $decodedPayload = $this->input('data.uplink_message.decoded_payload');
        
        if($decodedPayload){
            $mergeData = [
                'client_id' => $decodedPayload['client_id'],
                'client_secret' => $decodedPayload['client_secret'],
                'device_id' => $decodedPayload['device_id'],
                'device_prefix' => $decodedPayload['device_prefix'],
                'grant_type' => $decodedPayload['grant_type'],
                'hour_meter_active' => $decodedPayload['hour_meter_active'],
                'status' => $decodedPayload['status'],
            
                //mientras masdatos se envien en el payload de TTN, mas campos podemos habilitar acá

                //'status_text' => $decodedPayload['status_text'],
                //'battery' => $decodedPayload['battery'],
               // 'stack' => $decodedPayload['stack'],
              //  'humidity' => $decodedPayload['humidity'],
               // 'atmospheric_pressure' => $decodedPayload['atmospheric_pressure'],
                //'regulator01' => $decodedPayload['regulator01'],
               // 'regulator02' => $decodedPayload['regulator02'],
              //  'regulator03' => $decodedPayload['regulator03'],
              //  'regulator04' => $decodedPayload['regulator04']
            ];
            Log::debug('merge data',$mergeData);
            return $this->merge($mergeData);
        }
        
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(api()->validator($validator->errors()));
    }
}
