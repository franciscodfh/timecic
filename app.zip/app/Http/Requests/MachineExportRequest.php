<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class MachineExportRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'prefix' => 'sometimes|string|regex:/^\S*$/u',
            'beginDate' => 'sometimes|date_format:Y-m-d',
            'finalDate' => 'sometimes|date_format:Y-m-d|after:beginDate',
        ];
    }

    public function prepareForValidation()
    {
        $mergeData = [];

        if (!$this->has('sort'))
            $mergeData['sort'] = 'desc';

        if (!$this->has('sortField'))
            $mergeData['sortField'] = 'id';

        if (!$this->has('limit'))
            $mergeData['limit'] = 100;

        return $this->merge($mergeData);
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(api()->validator($validator->errors()));
    }
}
