<?php

namespace App\Http\Requests;

use Carbon\Carbon;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class GraphStatusMonthRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'device_id' => 'sometimes|string|regex:/^\S*$/u',
            'month' => 'sometimes|date_format:Y-m-d',
            'current_month' => 'required|date_format:m',
            'last_month' => 'required|date_format:m',
            'year' => 'required|date_format:Y',
        ];
    }

    public function prepareForValidation()
    {
        $mergeData = [];

        if (!$this->has('month'))
            $mergeData['current_month'] = Carbon::now()->format('m');
        else
            $mergeData['current_month'] = (new Carbon($this->get('month')))->format('m');

        if (!$this->has('last_month'))
            $mergeData['last_month'] = Carbon::now()->subMonth()->format('m');
        else
            $mergeData['last_month'] = (new Carbon($this->get('month')))->subMonth()->format('m');

        $mergeData['year'] = (new Carbon($this->get('month')))->format('Y');

        return $this->merge($mergeData);
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(api()->validator($validator->errors()));
    }
}
