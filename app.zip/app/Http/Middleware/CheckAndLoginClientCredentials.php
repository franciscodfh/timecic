<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

class CheckAndLoginClientCredentials
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\JsonResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if (Str::startsWith($request->route()->getPrefix(), 'oauth2')) {
            try {
                $proxy = $request::create('oauth/token', 'POST');
                $decodedPayload = $request->input('data.uplink_message.decoded_payload');
                if ($decodedPayload) {
                    $request->merge([
                        'grant_type' => $decodedPayload['grant_type'],
                        'client_id' => $decodedPayload['client_id'],
                        'client_secret' => $decodedPayload['client_secret'],
                        'scope' => $decodedPayload['scope'],
                    ]);
                }
                $response = Route::dispatch($proxy);
                $request->headers->set('Authorization', 'Bearer '. json_decode($response->getContent(), true)['access_token']);
                return $next($request);
            } catch (\Exception $exception) {
                return response()->json(['message' => 'Unauthorized'], 401);
            }
        } else {
            return response()->json(['message' => 'Unauthorized'], 401);
        }
    }
}
