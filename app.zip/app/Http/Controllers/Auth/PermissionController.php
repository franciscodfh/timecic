<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;

class PermissionController extends Controller
{
    public function index(): JsonResponse
    {
        try {
            $records = Permission::all();

            return api()->ok([
                'records' => $records
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al consultar registros', [], 500, $exception);
        }
    }

    public function store(Request $request)
    {
        try {
            $record = Permission::create($request->all());
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al guardar registro', [], 500, $exception);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $record = Permission::findOrFail($id);
            $record->update($request->all());
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al modificar registro', [], 500, $exception);
        }
    }

    public function destroy(Request $request, $id)
    {
        try {
            $record = Permission::findOrFail($id);
            $record->delete();
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al eliminar registro', [], 500, $exception);
        }
    }
}
