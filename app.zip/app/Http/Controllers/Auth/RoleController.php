<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/roles",
     *     summary="get records role",
     *     description="index records",
     *     operationId="roleIndex",
     *     tags={"role"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. role records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "records": { {"id":1,"name":"sysadmin","guard_name":"api","created_at":"2022-06-08T06:26:40.000000Z","updated_at":"2022-06-08T06:26:40.000000Z"},{"id":2,"name":"superadmin","guard_name":"api","created_at":"2022-06-08T06:26:40.000000Z","updated_at":"2022-06-08T06:26:40.000000Z"} }, "extra": {} } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. not get records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al consultar registros", "extra": {} }, summary="An result error exception.")
     *         )
     *     )
     * )
     */
    public function index(): JsonResponse
    {
        try {
            $records = Role::all();

            return api()->ok([
                'records' => $records
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al consultar registros', [], 500, $exception);
        }
    }

    public function store(Request $request)
    {
        try {
            $record = Role::create($request->all());
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al guardar registro', [], 500, $exception);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $record = Role::where('id', $id)->first();
            if (!$record) throw new \Exception('Rol no encontrado');
            $record->update($request->all());
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al modificar registro', [], 500, $exception);
        }
    }

    public function destroy(Request $request, $id)
    {
        try {
            $record = Role::where('id', $id)->first();
            if (!$record) throw new \Exception('Rol no encontrado');
            $record->delete();
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al eliminar registro', [], 500, $exception);
        }
    }
}
