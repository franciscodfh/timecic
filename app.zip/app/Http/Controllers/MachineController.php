<?php

namespace App\Http\Controllers;

use App\Exports\MachineExport;
use App\Exports\TrackExport;
use App\Http\Requests\MachineExportRequest;
use App\Http\Requests\MachineStoreRequest;
use App\Http\Requests\MachineUpdateRequest;
use App\Http\Requests\TrackExport as TrackExportRequest;
use App\Models\Machine;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class MachineController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/machines",
     *     summary="get records machine",
     *     description="index records",
     *     operationId="machineIndex",
     *     tags={"machine"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. machine records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "records": {}, "extra": {} } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. machine not get records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al consultar registros", "extra": {} }, summary="An result error exception.")
     *         )
     *     )
     * )
     */
    public function index(Request $request)
    {
        try {
            $records = Machine::with(['device:machine_id,prefix,id'])
                ->withTrashed()
                ->paginate($request->get('per_page') ?? 10);
            return $records;
        } catch (\Exception $exception) {
            return api()->error('Error al consultar registros', [], 500, $exception);
        }
    }

    /**
     * @OA\Post(
     *     path="/api/machines",
     *     summary="store machine",
     *     description="store new machine with device",
     *     operationId="machineStore",
     *     tags={"machine"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                     property="device_id",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="device_prefix",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="name",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="plate",
     *                     type="string"
     *                 ),
     *                 example={"device_id": "123", "device_prefix": "TEST", "name": "war machine", "plate": "TEST123"}
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. machine stored with device",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": {"data":{"record":{"name":"war machine","plate":"TEST123","updated_at":"2022-06-22T02:25:46.000000Z","created_at":"2022-06-22T02:25:46.000000Z","id":4},"extra": {}} } }, summary="An result object."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. machine not store",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Message description error", "extra": {}}, summary="An result error exception."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Error. validation",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Validation error.", "extra": { "errors": { "plate": {"The plate field is required"} } } }, summary="An result error exception."),
     *         )
     *     )
     * )
     */
    public function store(MachineStoreRequest $request)
    {
        try {
            DB::beginTransaction();
            $record = Machine::create($request->all());
            $record->device()->create(['id' => $request->get('device_id'), 'prefix' => $request->get('device_prefix')]);
            DB::commit();
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al guardar registro', [], 500, $exception);
        }
    }

    /**
     * @OA\Put(
     *     path="/api/machines/{machineId}",
     *     summary="update machine",
     *     description="update machine with device",
     *     operationId="machineUpdate",
     *     tags={"machine"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                  @OA\Property(
     *                     property="device_id",
     *                     type="string",
     *                 ),
     *                 @OA\Property(
     *                     property="device_prefix",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="name",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="plate",
     *                     type="string"
     *                 ),
     *                 example={"device_id": "123", "device_prefix": "TEST", "name": "war machine", "plate": "TEST123"}
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. machine updated with device",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "record": { "id": 0, "name": "war machine", "plate": "TEST123", "status": "stopped" }, "extra": {} } }, summary="An result object."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. machine not update",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Message description error", "extra": { "exception": "Message exception" } }, summary="An result error exception."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Error. validation",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Validation error.", "extra": { "errors": { "plate": {"The plate field is string"} } } }, summary="An result error exception."),
     *         )
     *     )
     * )
     */
    public function update(MachineUpdateRequest $request, $id)
    {
        try {
            $record = Machine::findOrFail($id);
            $record->update($request->all());

            if ($request->has('device_prefix')) {
                $record->device()->updateOrCreate([
                    'id' => $request->get('device_id'),
                ], [
                    'prefix' => $request->get('device_prefix'),
                ]);
            }

            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al modificar registro', [], 500, $exception);
        }
    }

    /**
     * @OA\Delete(
     *     path="/api/machines/{machineId}",
     *     summary="destroy record machine",
     *     description="delete records",
     *     operationId="machineDestroy",
     *     tags={"machine"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. machine deleted",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "record": { "id": 0, "name": "war machine", "plate": "TEST123", "status": "stopped" }, "extra": "[]" } }, summary="An result object."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. machine not deleted",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al eliminar registro", "extra": {} }, summary="An result error exception."),
     *         )
     *     )
     * )
     */
    public function destroy(Request $request, $id)
    {
        try {
            $record = Machine::findOrFail($id);
            $record->delete();
            $record->device()->delete();
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al eliminar registro', [], 500, $exception);
        }
    }

    /**
     * @OA\Get(
     *     path="/api/export/machines",
     *     summary="export xls records machine",
     *     description="export machines",
     *     operationId="machineExport",
     *     tags={"machine"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="beginDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-07",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="finalDate",
     *          in="query",
     *          required=false,
     *          example="2022-07-30",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="sort",
     *          in="query",
     *          required=false,
     *          example="asc",
     *          schema={
     *              "type"="string",
     *              "default"="desc"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="sortField",
     *          in="query",
     *          required=false,
     *          example="latitude",
     *          schema={
     *              "type"="string",
     *              "default"="id"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="limit",
     *          in="query",
     *          required=false,
     *          example="10",
     *          schema={
     *              "type"="numeric",
     *              "default"="100"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="prefix",
     *          in="query",
     *          required=false,
     *          example="123",
     *          description="device prefix",
     *          schema={
     *              "type"="string",
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. download file xls",
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error al exportar",
     *     )
     * )
     */
    public function export(MachineExportRequest $request)
    {
        try {
            $export = new MachineExport($request->all());
            $response = array(
                'name' => 'machines_' . now()->format('YmdHis') . '.csv',
                'file' => "data:application/vnd.ms-csv;base64," . base64_encode(Excel::raw($export, $export->writerType))
            );
            return api()->ok($response);
        } catch (\Exception $exception) {
            return api()->error('Error al exportar', [], 500, $exception);
        }
    }

    /**
     * @OA\Patch(
     *     path="/api/restore/machines/{machineId}",
     *     summary="restore record machine",
     *     description="restore records",
     *     operationId="machineRestore",
     *     tags={"machine"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. machine restored",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "record": { "id": 0, "name": "war machine", "plate": "TEST123", "status": "stopped", "deleted_at": "" }, "extra": "[]" } }, summary="An result object."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. machine not deleted",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al restaurar registro", "extra": {} }, summary="An result error exception."),
     *         )
     *     )
     * )
     */
    public function restore(Request $request, $id)
    {
        try {
            $record = Machine::withTrashed()->findOrFail($id);
            $record->restore();
            $record->device()->restore();
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al restaurar registro', [], 500, $exception);
        }
    }
}
