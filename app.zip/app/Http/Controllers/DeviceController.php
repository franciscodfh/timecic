<?php

namespace App\Http\Controllers;

use App\Http\Requests\DeviceStoreRequest;
use App\Models\Device;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DeviceController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/devices",
     *     summary="get records device",
     *     description="index records",
     *     operationId="deviceIndex",
     *     tags={"device"},
     *     @OA\Parameter(
     *          name="search",
     *          in="query",
     *          required=false,
     *          example="123",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. device records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "records": { {"id":"123","prefix":"TEST","machine_id":4,"deleted_at":null,"created_at":"2022-06-22T02:25:46.000000Z","updated_at":"2022-06-22T02:25:46.000000Z"} }, "extra": {} } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. devices not get records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al consultar registros", "extra": {} }, summary="An result error exception.")
     *         )
     *     )
     * )
     */
    public function index(Request $request)
    {
        try {
            $records = Device::query()->search($request->get('search') ?? null)
                ->withTrashed()
                ->get();
            return $records;
        } catch (\Exception $exception) {
            return api()->error('Error al consultar registros', [], 500, $exception);
        }
    }

    /**
     * @OA\Post(
     *     path="/api/devices",
     *     summary="store new device",
     *     description="store record",
     *     operationId="deviceStore",
     *     tags={"device"},
     *     @OA\Response(
     *         response=200,
     *         description="ok. device records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "record": { {"id":"123","prefix":"TEST","machine_id":4,"deleted_at":null,"created_at":"2022-06-22T02:25:46.000000Z","updated_at":"2022-06-22T02:25:46.000000Z"} }, "extra": {} } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. store",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al guardar registro", "extra": {} }, summary="An result error exception.")
     *         )
     *     )
     * )
     */
    public function store(DeviceStoreRequest $request)
    {
        try {
            DB::beginTransaction();
            $record = Device::create($request->all());
            DB::commit();
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            DB::rollBack();
            return api()->error('Error al guardar registro', [], 500, $exception);
        }
    }
}
