<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserStoreRequest;
use App\Http\Requests\UserUpdateRequest;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/users",
     *     summary="get records user",
     *     description="index records",
     *     operationId="userIndex",
     *     tags={"user"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. user records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "records": {}, "extra": {} } }, summary="An result object.")
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. user not get records",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al consultar registros", "extra": {} }, summary="An result error exception.")
     *         )
     *     )
     * )
     */
    public function index(Request $request)
    {
        try {
            $records = User::with([
                'roles' => fn($q) => $q->select(['name'])
            ])->withTrashed()->paginate($request->get('per_page') ?? 10);

            return $records;
        } catch (\Exception $exception) {
            return api()->error('Error al consultar registros', [], 500, $exception);
        }
    }

    /**
     * @OA\Post(
     *     path="/api/users",
     *     summary="store new user",
     *     description="store new user",
     *     operationId="userStore",
     *     tags={"user"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                     property="name",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="email",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="password",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="role_id",
     *                     type="integer"
     *                 ),
     *                 example={"name": "cristiano", "email": "cr7@gmail.com", "password": "123456", "role_id": 1 }
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. user stored with device",
     *         @OA\JsonContent(
     *             @OA\Examples(
     *                  example="result",
     *                  value={"data": { "record": {"id": 1, "name": "cristiano", "email": "cr7@gmail.com", "password": "123456", "roles": { { "id": 0, "name": "admin" } } }, "extra": {} } },
     *                  summary="An result object."
     *              ),
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. user not store",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Message description error", "extra": {} }, summary="An result error exception."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Error. validation",
     *         @OA\JsonContent(
     *             @OA\Examples(
     *                  example="result",
     *                  value={"error": "Validation error.", "extra": { "errors": { "email": {"The email must be a valid email address."} } } },
     *                  summary="An result error exception."
     *              ),
     *         )
     *     )
     * )
     */
    public function store(UserStoreRequest $request)
    {
        try {
            $role = Role::findOrFail($request->get('role_id'));
            $record = User::create($request->except(['role_id']));
            $record->syncRoles($role);
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al guardar registro', [], 500, $exception);
        }
    }

    /**
     * @OA\Put(
     *     path="/api/users/{userId}",
     *     summary="update user",
     *     description="update user",
     *     operationId="userUpdate",
     *     tags={"user"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                     property="name",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="email",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="password",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="role_id",
     *                     type="integer"
     *                 ),
     *                 example={"name": "cristiano", "email": "cr7@gmail.com", "password": "123456", "role_id": 1 }
     *             )
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. user updated",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "record": {"name": "cristiano", "email": "cr7@gmail.com", "password": "123456", "roles": { { "id": 0, "name": "admin" } } }, "extra": {} } }, summary="An result object."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. user not updated",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Message description error", "extra": {}}, summary="An result error exception."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Error. validation",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Validation error.", "extra": { "errors": { "email": {"The email must be a valid email address."} } } }, summary="An result error exception."),
     *         )
     *     )
     * )
     */
    public function update(UserUpdateRequest $request, $id)
    {
        try {
            $role = Role::findOrFail($request->get('role_id'));
            $record = User::findOrFail($id);
            $record->update($request->all());
            $record->syncRoles($role);
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al modificar registro', [], 500, $exception);
        }
    }

    /**
     * @OA\Delete(
     *     path="/api/users/{userId}",
     *     summary="destroy record",
     *     description="delete",
     *     operationId="userDestroy",
     *     tags={"user"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. record deleted",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "record": {"name": "cristiano", "email": "cr7@gmail.com", "password": "123456", "roles": { { "id": 0, "name": "admin" } } }, "extra": {} } }, summary="An result object."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. user not deleted",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al eliminar registro", "extra": {} }, summary="An result error exception."),
     *         )
     *     )
     * )
     */
    public function destroy(Request $request, $id)
    {
        try {
            $record = User::findOrFail($id);
            $record->delete();
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al eliminar registro', [], 500, $exception);
        }
    }

    /**
     * @OA\Patch(
     *     path="/api/restore/users/{userId}",
     *     summary="restore record",
     *     description="restore",
     *     operationId="userRestore",
     *     tags={"user"},
     *     @OA\Parameter(
     *          name="Authorization",
     *          in="header",
     *          required=true,
     *          example="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOi...",
     *          schema={
     *              "type"="string"
     *          }
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="ok. record restored",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"data": { "record": {"name": "cristiano", "email": "cr7@gmail.com", "password": "123456", "delete_at": "null","roles": { { "id": 0, "name": "admin" } } }, "extra": {} } }, summary="An result object."),
     *         )
     *     ),
     *     @OA\Response(
     *         response=500,
     *         description="Error. user not deleted",
     *         @OA\JsonContent(
     *             @OA\Examples(example="result", value={"error": "Error al restayrar registro", "extra": {} }, summary="An result error exception."),
     *         )
     *     )
     * )
     */
    public function restore(Request $request, $id)
    {
        try {
            $record = User::withTrashed()->findOrFail($id);
            $record->restore();
            return api()->ok([
                'record' => $record
            ]);
        } catch (\Exception $exception) {
            return api()->error('Error al restaurar registro', [], 500, $exception);
        }
    }
}
