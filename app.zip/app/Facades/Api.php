<?php

namespace App\Facades;

use App\Services\ApiResponse;
use Illuminate\Support\Facades\Facade;

class Api extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return ApiResponse::class;
    }
}
