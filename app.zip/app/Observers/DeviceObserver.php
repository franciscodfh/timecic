<?php

namespace App\Observers;

use App\Models\Device;

class DeviceObserver
{
    /**
     * Handle events after all transactions are committed.
     * @var bool
     */
    public $afterCommit = true;
    /**
     * @param Device $device
     * @return void
     */
    public function created(Device $device): void
    {
        // create table migration
        $device->migrateUp();
    }
}
