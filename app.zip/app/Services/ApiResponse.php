<?php

namespace App\Services;

use Illuminate\Http\JsonResponse;
use Throwable;

class ApiResponse
{
    /**
     * @param array $data
     * @param array $extra
     * @param int $code
     * @return JsonResponse
     */
    public function ok(array $data = [], array $extra = [], int $code = 200): JsonResponse
    {
        return response()->json([
            'data' => $data,
            'extra' => $extra
        ], $code);
    }

    /**
     * @param $message
     * @param array $extra
     * @param int $code
     * @param Throwable|null $e
     * @return JsonResponse
     */
    public function error($message, array $extra = [], int $code = 400, ?Throwable $e = null): JsonResponse
    {
        $_extra = [
            'exception' => optional($e)->getMessage(),
            'trace' => app()->environment('production') ? null : optional($e)->getTrace()
        ];

        return response()->json([
            'error' => $message,
            'extra' => array_merge($extra, $_extra)
        ], $code ?? 400);
    }

    /**
     * @param $errors
     * @return JsonResponse
     */
    public function validator($errors): JsonResponse
    {
        return response()->json([
            'error' => 'Validation error.',
            'extra' => [
                'errors' => $errors
            ]
        ], 422);
    }
}
