<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        if (env('LOG_QUERIES')) {
            DB::listen(function ($query) {
                File::append(
                    storage_path('/logs/query.log'),
                    $query->sql . ' [' . collect($query->bindings)->map(function ($item) {
                        if ($item instanceof \DateTime) $item->format('Y-m-d H:i:s');
                        return $item;
                    })->implode(', ') . '] (' . $query->time . 'ms)' . PHP_EOL
                );
            });
        }
    }
}
