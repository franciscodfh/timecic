<?php

namespace App\Models\Relations;

use App\Models\Device;
use Illuminate\Database\Eloquent\Relations\HasOne;

trait MachineRelations {

    public function device(): HasOne
    {
        return $this->hasOne(Device::class, 'machine_id', 'id');
    }
}
