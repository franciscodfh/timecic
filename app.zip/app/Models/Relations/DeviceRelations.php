<?php

namespace App\Models\Relations;

use App\Models\Machine;
use App\Models\Track;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

trait DeviceRelations {

    public function getInstanceTrack()
    {
        $instance = $this->newRelatedInstance(Track::class);
        $instance->setTable($this->id.'_tracks');
        return $instance;
    }

    public function tracks(): HasMany
    {
        $instance = $this->newRelatedInstance(Track::class);
        $instance->setTable($this->id.'_tracks');
        return $this->newHasMany(
            $instance->newQuery(), $this, $instance->getTable().'.device_id', 'id'
        );
    }

    public function latestTrack()
    {
        $instance = $this->newRelatedInstance(Track::class);
        $instance->setTable($this->id.'_tracks');
        return $this->newHasMany(
            $instance->newQuery(), $this, $instance->getTable().'.device_id', 'id'
        )
            ->where('created_at', '>=', now()->subMinutes(15))
            ->orderBy('created_at', 'desc');
    }

    public function machine(): BelongsTo
    {
        return $this->belongsTo(Machine::class, 'machine_id', 'id');
    }
}
