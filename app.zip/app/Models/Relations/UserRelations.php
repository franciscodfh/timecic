<?php

namespace App\Models\Relations;

use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Support\Collection;
use Spatie\Permission\PermissionRegistrar;

trait UserRelations {

    public function role()
    {
        return $this->morphToMany(
            config('permission.models.role'),
            'model',
            config('permission.table_names.model_has_roles'),
            config('permission.column_names.model_morph_key'),
            PermissionRegistrar::$pivotRole
        )->limit(1);
    }

    public function permissionByRoles(): Collection
    {
        return $this->loadMissing([
            'roles' => fn ($q) => $q->select('id','name'),
            'roles.permissions' => fn ($q) => $q->select('name')
        ])->roles->flatMap(function ($role) {
                return $role->permissions;
            })->sort()->values();
    }
}
