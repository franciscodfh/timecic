<?php

namespace App\Models;

use App\Models\Relations\MachineRelations;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Machine extends Model
{
    use HasFactory, SoftDeletes, MachineRelations;

    /**
     * types status machine
     */
    const STOPPED = 1;
    const MOVING = 2;
    const IDLING = 3;

    const STATUS = [
        self::STOPPED => 'stopped',
        self::MOVING => 'moving',
        self::IDLING => 'idling'
    ];

    protected $fillable = [
        'name',
        'plate',
        'status',
        'delete_at',
    ];

    public function status(): Attribute
    {
        return Attribute::make(
            get: fn ($value) => self::STATUS[$value]
        );
    }
}
